module.exports = function(data, error){
    if(error){
        return error;
    }
    else
    return data;
}