// var Connection = require('tedious').Connection;  
    // var config = {  
        // server: 'SQL5049.site4now.net',  //update me
        // authentication: {
            // type: 'default',
            // options: {
                // userName: 'DB_A5E03A_vaishnov440_admin', //update me
                // password: 'Samsung@440'  //update me
            // }
        // },
        // options: {
            // // If you are on Microsoft Azure, you need encryption:
            // encrypt: true,
            // database: 'DB_A5E03A_vaishnov440'  //update me
        // }
    // };  

// var connection = new Connection(config);

// connection.on('connect', function (err) {
    // if (err) {
        // console.log(err);
    // } else {
        // console.log('Connected by durgesh');
    // }
// });

// //module.exports = connection;



var Connection = require('tedious').Connection;  
    var config = {  
        server: 'SQL5049.site4now.net',  //update me
        authentication: {
            type: 'default',
            options: {
                userName: 'DB_A5E03A_vaishnov440_admin', //update me
                password: 'Samsung@440'  //update me
            }
        },
        options: {
            // If you are on Microsoft Azure, you need encryption:
            encrypt: true,
            database: 'DB_A5E03A_vaishnov440' , //update me
			rowCollectionOnDone: true,
			useColumnNames: false
        }
    };  
    var connection = new Connection(config);  
    connection.on('connect', function(err) {  
        // If no error, then good to proceed.
        console.log("Connected");  
    });
	
	
	
	module.exports = connection;