const mongoose = require('mongoose');

const ProductSchema = mongoose.Schema({
    productId:Number,
    title: String,
    description: String,
    published:Boolean,
    price: Number,
    company: String
}, {
    timestamps: true
});

module.exports = mongoose.model('Products', ProductSchema);