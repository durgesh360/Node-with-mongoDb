# NodeAPI
How to create Restful CRUD API with Node.js MongoDB and Express

Update MongoDB connection Url in config.js file

Install Node.js and relevant dependencies in your app folder
