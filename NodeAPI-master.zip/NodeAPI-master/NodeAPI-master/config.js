module.exports = {
    url: 'mongodb+srv://test:test123@cluster0-dhrfq.mongodb.net/productDatabase?retryWrites=true&w=majority',
    serverport: 3000 
}