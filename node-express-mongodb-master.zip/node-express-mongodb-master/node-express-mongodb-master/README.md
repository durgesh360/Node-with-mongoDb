# Node.js Express & MongoDB: CRUD Rest APIs

For more detail, please visit:
> [Node.js, Express & MongoDb: Build a CRUD Rest Api example](https://bezkoder.com/node-express-mongodb-crud-rest-api/)

Fullstack:
> [Vue.js + Node.js + Express + MongoDB example](https://bezkoder.com/vue-node-express-mongodb-mevn-crud/)

> [Angular + Node.js + Express + MongoDB example](https://bezkoder.com/angular-mongodb-node-express/)

> [React + Node.js + Express + MongoDB example](https://bezkoder.com/react-node-express-mongodb-mern-stack/)

## Project setup
```
npm install
```

### Run
```
node server.js
```
